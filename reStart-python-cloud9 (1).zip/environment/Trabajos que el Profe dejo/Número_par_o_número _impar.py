print("******************************************************")
print("* Programa que determina si un número es par o impar *")
print("****************************************************** \n")

número = int(input("Por favor introduce un número entero: "))

if número % 2 == 0:
    print("El número ", número, " es par.")
elif número % 2 == 1:
    print("el número ", número, " es impar.")