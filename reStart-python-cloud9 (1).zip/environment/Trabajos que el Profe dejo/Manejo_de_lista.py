números = []
longitud_lista = int(input("Cuántos números enteros contendrá la lista?: "))

for _ in range(longitud_lista):
    números.append(int(input("Introduce un número entero: ")))
    
print(f"\nLista: {números} \La suma total de los elementos es: {sum(números)}")