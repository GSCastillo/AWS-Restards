número_1, número_2 = 0, 1
while número_2 <= 1597:
    print(número_1, número_2, end=" ")
    número_1 = número_1 + número_2
    número_2 = número_1 + número_2