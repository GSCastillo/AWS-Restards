print("Calculadora con una sola variable \n")

print("********************")
print("* Menú de opciones *")
print("********************")

print("1. Suma")
print("2. Resta")
print("3. Multiplicación")
print("4. División")
print("5. División entera")
print("6. Exponente")
print("7. modulo o resto \n")

número = int(input("introduce la opción deseada: "))

if número == 1:
    
    print("Elejiste Suma \n")
    número = int(input("Introduce el primer número:"))
    número += int(input("Introduce el segundo número:"))
    print("El resultado de la suma es:", número)
    
elif número == 2:
    
    print("Elejiste Resta \n")
    número = int(input("Introduce el primer número:"))
    número -= int(input("Introduce el segundo número:"))
    print("El resultado de la resta es:", número)

elif número == 3:
    
    print("Elejiste Multiplicación \n")
    número = int(input("Introduce el primer número:"))
    número *= int(input("Introduce el segundo número:"))
    print("El resultado de la multiplicación es:", número)

elif número == 4:
    
    print("Elejiste División \n")
    número = float(input("Introduce el primer número:"))
    número /= float(input("Introduce el segundo número:"))
    print("El resultado de la divición es:", round(número, 2))
    
elif número == 5:
    
    print("Elejiste División Entera \n")
    número = int(input("Introduce el primer número:"))
    número //= int(input("Introduce el segundo número:"))
    print("El resultado de la división entera es:", número)

elif número == 6:
    
    print("Elejiste Exponente \n")
    número = int(input("Introduce el primer número:"))
    número **= int(input("Introduce el segundo número:"))
    print("El resultado del exponente es:", número)

elif número == 7:
    
    print("Elejiste Modulo o Resto \n")
    número = int(input("Introduce el primer número:"))
    número %= int(input("Introduce el segundo número:"))
    print("El modulo o resto es:", número)

else:
    print("La opción elejida no existe, vuelve a intentar.")