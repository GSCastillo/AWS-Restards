números = [1, 2, 3, 4, 5]
print(f"Lista números:  {números}")

números_eliminados = []
números_eliminados.append(números.pop(0))
números_eliminados.append(números.pop())

print(f"Lista números: {números} \nLista números eliminados: {números_eliminados}")