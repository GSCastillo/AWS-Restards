my_mixed_type_list = [45, 290578, 1.02, True, "my dog is on the bed.", "45"]
for item in my_mixed_type_list:
    print("{} is of the data type {}".format(item,type(item)))
    