print("Hello, World")
print(" !HOLA, MUNDO!!!" )