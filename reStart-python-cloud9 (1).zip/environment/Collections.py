my_fruit_list = ["apple", "banana", "cherry"]
print(my_fruit_list)
print(type(my_fruit_list))
print(my_fruit_list[0])
print(my_fruit_list[1])
print(my_fruit_list[2])

my_fruit_list[2] = "orange"
print(my_fruit_list)

my_final_answer_tuple = ("apple", "banana", "pineapple")
print(my_final_answer_tuple)
print(type(my_final_answer_tuple))
print(my_final_answer_tuple[0])
print(my_final_answer_tuple[1])
print(my_final_answer_tuple[2])

my_favorite_fruit_diccionary = {
    "Akura" : "apple",
    "Saanvi" : "banana",
    "Paulo" : "pineapple"
}
print(my_favorite_fruit_diccionary)
print(type(my_favorite_fruit_diccionary))
print(my_favorite_fruit_diccionary["Akura"])
print(my_favorite_fruit_diccionary["Saanvi"])
print(my_favorite_fruit_diccionary["Paulo"])
print("Saanvi's favorite fruit is " + my_favorite_fruit_diccionary['Saanvi'])